#include "db_struct.h"

int display_database ( Slist_word **hash_table )
{
    //Loop to print the hash_table
    for ( int i = 0; i < 27; i++)
    {
	Slist_word *temp1 = hash_table[i];
	//Loop to traverse through the word list
	while ( temp1 != NULL )
	{
	    printf("\r[%2d] [%-5s] in %d file(s) ", i, temp1->word, temp1->file_count); 
	    Slist_file *temp2 = temp1 -> flink;
	    //Loop to traverse through the file list
	    while ( temp2 != NULL )
	    {
	    printf("%5s :- %1d time(s)\n\t\t\t  ", temp2->file_name, temp2->word_count); 
	    temp2 = temp2->f_link;
	    }
	    temp1 = temp1->w_link;
	}
    }
    //Return SUCCESS if hash_table is displayed
    return SUCCESS;
}
