#include "db_struct.h"

int update_database ( Slist_word **hash_table, int argc, char **argv, F_name **file1, F_name **files )
{
    F_name *temp1 = *files, *temp2, *temp;
    int j = 1, ind[argc], k;
    if ( argc == 1 )
	return FILE_NOT_PRESENT;
    //Open the backup file in read mode
    FILE *fptr = fopen ( "backup.txt", "r" );
    //Return FILE_NOT_PRESENT if fptr returns NULL
    if ( fptr == NULL )
	return FILE_NOT_PRESENT;
    //Loop through the file and extract the data to be updated
    char in, line[50], *lined, *i = NULL, *word = NULL, *file_name = NULL;
    int index, file_count, word_count;
    //Scan the index from file
    while ( fscanf(fptr,"%4s",line) != EOF )
    {
	//Extract index
	i = strtok(line,"#;");
	index = atoi(i);
	Slist_word *word_h = hash_table[index];
	//Scan next line
	if ( (in = fgetc(fptr)) == '\n' )
	{
	    //Traverse through the line and create hash_table
	    while ( (in = fgetc(fptr)) == '[' )
	    {
		j = 1;
		//Scan each line and create a word node
		fscanf(fptr,"%[^\n]",line);
		lined = strtok(line,"#;]");
		word = lined;
		lined = strtok(NULL,"#;]");
		file_count = atoi(lined);
		lined = strtok(NULL,"#;]");
		Slist_word *word_node = malloc(sizeof(Slist_word));
		//Update hash_table[index] when first node is found
		if ( hash_table[index] == NULL )
		{
		    hash_table[index] = word_node;
		    word_h = hash_table[index];
		}
		//Update previous link for other words
		else
		{
		    word_h -> w_link = word_node;
		    word_h = word_h -> w_link;
		}
		//Copy data to node
		strcpy(word_node->word, word);
		word_node->file_count = file_count;
		word_node->flink = NULL;
		Slist_file *pre = word_node->flink;
		//Loop to create file nodes
		while ( lined != NULL )
		{
		    Slist_file *w_file = malloc(sizeof(Slist_file));
		    file_name = lined;
		    //Create file list of all files names from backup file
		    for ( j = 1; j < argc; j++ )
		    {
			//Update head when first node is created
			if ( temp1 == NULL )
			{
			    F_name *new = malloc(sizeof(F_name));
			    strcpy(new->f_name, file_name);
			    new -> fn_link = NULL;
			    *files = new;
			    temp1 = *files;
			    break;
			}
			//Traversal through list 
			temp1 = *files;
			if ( strcmp(file_name, argv[j]) != 0 ) 
			{
			    while ( temp1 != NULL && strcmp(file_name, temp1->f_name) != 0 ) 
			    {
				temp2 = temp1;
				temp1 = temp1 -> fn_link;
			    }
			    //File name not detected create a node and update previous link
			    if ( temp1 == NULL && strcmp(file_name, argv[j]) != 0 )
			    {
				temp1 = *files;
				F_name *new = malloc(sizeof(F_name));
				strcpy(new->f_name, file_name);
				new -> fn_link = NULL;
				temp2 -> fn_link = new;
				break;
			    }
			}
			//If file name found break the loop
			else
			{
			    break;
			}
		    }
		    lined = strtok(NULL,"#;]");
		    word_count = atoi(lined);
		    lined = strtok(NULL,"#;]");
		    strcpy(w_file->file_name, file_name);
		    w_file->word_count = word_count;
		    w_file->f_link = NULL;
		    if ( pre == NULL )
			word_node->flink = w_file;
		    else
			pre -> f_link = w_file;
		    pre = w_file;
		}
		//Break loop if list of words are added to added to hash_table[index]
		in = fgetc(fptr);
	    }
	}
	temp1 = *files;
    }
    temp1 = *files;
    j = 1;
    //Loop to add files from command line that are not present in list of files
    while ( j < argc )
    {
	//Compare each argument with the file list
	if ( strcmp(argv[j], temp1->f_name) == 0 )
	{
	    //Move to next argument if file exists
	    j++;
	    temp1 = *files;
	}
	else
	{
	    //Traverse through the list if file name not found
	    temp2 = temp1;
	    temp1 = temp1->fn_link;
	    //If file name not presnt in the list then create a node and update database
	    if ( temp1 == NULL && strcmp(temp2->f_name, argv[j]) != 0 )
	    {
		ind[k] = j;
		//If all files are added to the list then break the loop
		if ( j == argc-1 )
		    break;
		//If not move to next file name
		else
		{
		    k++;
		    j++;
		    temp1 = *files;
		}
	    }
	}
    }
    k = 0;
    temp = temp2;
    while ( ind[k] > 0 )
    {
	F_name *file = malloc(sizeof(F_name));
	strcpy(file->f_name, argv[ind[k]]);
	file->fn_link = NULL;
	temp2->fn_link = file;
	temp2 = temp2->fn_link;
	k++;
    }
    *file1 = temp->fn_link;
    //Return SUCCESS on updating the database
    return SUCCESS;
}
