#include "db_struct.h"

int search_database ( Slist_word **hash_table, char *word )
{
    int index, len;
    //Find the index to search in hash_table
    if ( isalpha(word[0]) )
	index = (tolower(word[0]) - 'a') % 27;
    else
	index = 26;
    len = strlen(word);
    char word1[len-1], word2[len-1];
    strcpy(word1, word);
    //Loop through the word list
    Slist_word *temp1 = hash_table[index];
    while ( temp1 != NULL )
    {
	//Compare if words match
	strcpy(word2, temp1->word);
	if ( strcmp(word1, word2) == 10 )
	{
	    //Print the data if word is found
	    printf("\r[%2d] [%-5s] in %d file(s) ", index, temp1->word, temp1->file_count);
	    Slist_file *temp2 = temp1->flink;
	    //Loop to traverse through the file list
	    while ( temp2 != NULL )
	    {
		printf("%5s :- %1d time(s)\n\t\t\t  ", temp2->file_name, temp2->word_count);
		temp2 = temp2->f_link;
	    }
	    //Return SUCCESS if word is found
	    return SUCCESS;
	}
	temp1 = temp1->w_link;
    }
    //Return DATA_NOT_FOUND if word is not present in the hash_table[index]
    return DATA_NOT_FOUND;
}
