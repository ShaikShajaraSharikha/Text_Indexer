#include "db_struct.h"

int save_database ( Slist_word **hash_table )
{
    //Open a default backup file in write mode
    FILE *fptr = fopen("backup.txt", "w");
    //Loop through the hash_table
    for ( int i = 0; i < 27; i++)
    {
	Slist_word *temp1 = hash_table[i];
	//Print the data if hash_table[index] is not NULL
	if ( temp1 != NULL )
	{
	    fprintf(fptr,"#%d;\n",i);
	    //Traverse through the word list
	    while ( temp1 != NULL )
	    {
		fprintf(fptr,"[%s];%d;", temp1->word, temp1->file_count);
		Slist_file *temp2 = temp1 -> flink;
		//Traverse through the file list
		while ( temp2 != NULL )
		{
		    fprintf(fptr,"%s;%d;", temp2->file_name, temp2->word_count);
		    temp2 = temp2->f_link;
		}
		fprintf(fptr,"#\n");
		temp1 = temp1 -> w_link;
	    }
	}
    }
    return SUCCESS;
}
