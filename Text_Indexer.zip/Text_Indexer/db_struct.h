#ifndef SLIST_H
#define SLIST_H

#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE 1
#define DATA_NOT_FOUND 2
#define FILE_NOT_PRESENT 3
#define DUPLICATE_FILE 4

//Structure to keep record of file names
typedef struct file_inserted
{
    char f_name[10];
    struct file_inserted *fn_link;
} F_name;

//Structure to keep record of word count
typedef struct flink
{
    char file_name[10];
    int word_count;
    struct flink *f_link;
} Slist_file;

//Structure to keep record of file count
typedef struct wlink
{
    char word[10];
    int file_count;
    Slist_file *flink;
    struct wlink *w_link;
} Slist_word;

//Function Prototypes for Insert search
int create_database ( Slist_word **, F_name **, int, char ** );
int display_database ( Slist_word ** );
int search_database ( Slist_word **, char * );
int update_database ( Slist_word **, int, char **, F_name **, F_name **);
int save_database ( Slist_word ** );

#endif
