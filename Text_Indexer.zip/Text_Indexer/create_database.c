#include "db_struct.h"

int create_database ( Slist_word **hash_table, F_name **file1, int argc, char **argv )
{
    F_name *temp1, *temp2;
    int i = 0;
    if ( *file1 == NULL )
    {
	//Return FILE_NOT_PRESENT if no files are passed through command-line
	if ( argc == 1 )
	    return FILE_NOT_PRESENT;
	else
	    //Increment i to store all files in a list
	    i++;
	//Loop to create a list of files
	while ( i < argc )
	{
	    //Create a node to store file names
	    F_name *new = malloc(sizeof(F_name)), *temp1;
	    strcpy(new->f_name, argv[i]);
	    new->fn_link = NULL;
	    //Update head when first file is stored
	    if ( *file1 == NULL )
	    {
		*file1 = new;
		temp1 = *file1;
	    }
	    //Update previous link for other nodes
	    else
	    {
		//Loop till the end of list and update new node
		while ( temp1 -> fn_link != NULL )
		{
		    temp1 = temp1 -> fn_link;
		}
		temp1 -> fn_link = new;
	    }
	    i++;
	}
	temp1 = *file1;
	//Loop to compare all file names
	while ( temp1 != NULL )
	{
	    temp2 = temp1 -> fn_link;
	    while ( temp2 != NULL )
	    {
		//Return DUPLICATE_FILE if files are equal
		if ( strcmp(temp1 -> f_name, temp2 -> f_name) == 0 )
		    return DUPLICATE_FILE;
		temp2 = temp2 -> fn_link;
	    }
	    temp1 = temp1 -> fn_link;
	}
    }
    char word1[10];
    int x;
    temp1 = *file1;
    Slist_word *word;
    Slist_file *file;
    //Traverse through the list of files and create hash_table
    while ( temp1 != NULL )
    {
	FILE *fptr = fopen ( temp1 -> f_name, "r" );
	if ( fptr == NULL )
	    return FILE_NOT_PRESENT;
	//Scan every word from .txt file
	while ( fscanf(fptr, "%s", word1) != EOF)
	{
	    //Find index
	    if ( isalpha(word1[0]) )
		x = (tolower(word1[0]) - 'a') % 27;
	    else
		x = 26;
	    //Update hash_table for first word
	    if ( hash_table[x] == NULL )
	    {
		Slist_word *word_node = malloc(sizeof(Slist_word));
		strcpy(word_node->word, word1);
		word_node->file_count = 1;
		word_node->flink = malloc(sizeof(Slist_file));
		strcpy(word_node->flink->file_name, temp1->f_name);
		word_node->flink->word_count = 1;
		word_node->flink->f_link = NULL;
		word_node->w_link = NULL;
		hash_table[x] = word_node;
	    }
	    //Traverse through the hash_table[index] to compare word and file
	    else 
	    {
		word = hash_table[x];
		//Traverse through the word list
		while ( word != NULL )
		{
		    //If words match
		    if ( strcmp(word->word, word1) == 0 )
		    {
			//Traverse through the file list
			file = word->flink;
			while ( file != NULL )
			{
			    //Increment word count if files match
			    if ( strcmp(file->file_name, temp1->f_name) == 0 )
			    {
				file->word_count++;
				break;
			    }
			    //Increment file count and create a file node
			    else if ( file->f_link == NULL )
			    {
				if ( strcmp(file->file_name, temp1->f_name) == 0 )
				    continue;
				else
				{
				    word->file_count++;
				    Slist_file *file_node = malloc(sizeof(Slist_file));
				    strcpy(file_node->file_name, temp1->f_name);
				    file_node->word_count = 1;
				    file_node->f_link = NULL;
				    file->f_link = file_node;
				    break;
				}
			    }
			    file = file->f_link;
			}
			break;
		    }
		    //If words doesn't match traverse till the last node and create a word node
		    else
		    {
			if ( word -> w_link == NULL )
			{
			    Slist_word *word_node = malloc(sizeof(Slist_word));
			    strcpy(word_node->word, word1);
			    word_node->file_count = 1;
			    word_node->flink = malloc(sizeof(Slist_file));
			    strcpy(word_node->flink->file_name, temp1->f_name);
			    word_node->flink->word_count = 1;
			    word_node->flink->f_link = NULL;
			    word_node->w_link = NULL;
			    word -> w_link = word_node;
			    break;
			}
		    }
		    word = word->w_link;
		}
	    }
	}
	//Clost the file and read next file
	fclose(fptr);
	temp1 = temp1 -> fn_link;
    }
    //Return SUCCESS if database is created
    return SUCCESS;
}
