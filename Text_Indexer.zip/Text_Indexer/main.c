/* Documentation
Name:        Shaik Shajara Sharikha
Date:        02/01/2020
Description: The Technique of searching a single document or a collection of documents or in database for a particular text.
             Using database technique Create database, Display database, Search database, Update database and Save database
             are the different options given.
*/

#include "db_struct.h"

int main(int argc, char **argv)
{
    int choice, result;
    char option, word[10];
    //Declare structure for file names and hash_table
    F_name *files1 = NULL;
    F_name *files2 = NULL;
    Slist_word *hash_table[27] = {NULL};
    do
    {
	//Prompt user if wants to continue or not
	printf("1. Create Database\n2. Display Database\n3. Search Database\n4. Update Database\n5. Save Database\n6. Exit\nChoice :: ");
	scanf("%d", &choice);
	switch ( choice )
	{
	    default :
		printf("ERROR : Option is invalid\n");
		break;
	    case 1 :
		//Create database function call
		result = create_database ( hash_table, &files1, argc, argv );
		if ( result == SUCCESS )
		    printf("INFO : Database is created\n");
		else if ( result == DUPLICATE_FILE )
		    printf("ERROR : Duplicate file is passed\n");
		else if ( result == FILE_NOT_PRESENT )
		    printf("ERROR : File is not present\n");
		else
		    printf("ERROR : Node is not created\n");
		break;
	    case 2 :
		//Function call to display database
		if ( display_database ( hash_table ) == SUCCESS )
		    printf("\rINFO : Hash table is printed\n");
		break;
	    case 3 :
		printf("Enter the word you want to search : ");
		__fpurge(stdin);
		fgets(word, 10, stdin);
		//Function call to search word in database
		result = search_database ( hash_table, word );
		if ( result == SUCCESS )
		    printf("\rINFO : Data found\n");
		else
		    printf("INFO : Data not found\n");
		break;
	    case 4 :
		//Update database function call
		result = update_database ( hash_table, argc, argv, &files1, &files2 );
		if ( result == SUCCESS )
		    printf("INFO : Database is updated\n");
		else if ( result == FILE_NOT_PRESENT )
		    printf("ERROR : No backup file detected\n");
		else if ( result == DUPLICATE_FILE )
		    printf("ERROR : Database is not updated\nERROR : Duplicate file is passed");
		break;
	    case 5 :
		//Save database function call
		if ( save_database ( hash_table ) == SUCCESS )
		    printf("INFO : Database is saved\n");
		break;
	    case 6 :
		printf("INFO : Exiting Operation\n");
		exit(0);
	}
	printf("Do you want to continue (y/n) ? ");
	scanf("\n%c", &option);
    } while ( option == 'y' );
}
